## ----- pacotes
library(xtable)

## ----- dados
x <- rnorm(10)
y <- rnorm(10)
x; y

## ----- fig
plot(y ~ x)

## ----- tab1
print(xtable(head(iris), caption = "Legenda.", label = "tab:tab1"),
   caption.placement = "top")
    